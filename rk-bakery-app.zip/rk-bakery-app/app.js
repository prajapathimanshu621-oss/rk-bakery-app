function order(){

let phone="91XXXXXXXXXX"

let msg="Hello RK Bakery, I want to order cake"

window.open(
"https://wa.me/"+phone+"?text="+encodeURIComponent(msg)
)

}